package com.cg.ebill.service;

import java.util.ArrayList;

public interface IEBillService {
	public ArrayList getDetails();

}
