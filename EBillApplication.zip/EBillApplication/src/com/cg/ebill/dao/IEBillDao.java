package com.cg.ebill.dao;

import java.util.ArrayList;

public interface IEBillDao{
	public ArrayList getDetails();
	

}
