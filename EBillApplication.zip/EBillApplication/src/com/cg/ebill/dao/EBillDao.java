package com.cg.ebill.dao;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.cg.ebill.bean.EBean;

public class EBillDao implements IEBillDao{
	
public ArrayList getDetails()
{
	ArrayList<EBean> list=new ArrayList<EBean>();
	EBean b=new EBean();
	try
	{
	InitialContext ic=new InitialContext();
	DataSource ds=(DataSource)ic.lookup("java:/OracleDS");
	Connection con=ds.getConnection();
	Statement st=con.createStatement();
	ResultSet rs=st.executeQuery("select * from consumers");
	while(rs.next()){
			b.setConsumer_num(rs.getInt("consumer_num"));
		        b.setConsumer_name(rs.getString("consumer_name"));
	           b.setAddress(rs.getString("address"));
	}
	list.add(b);
	

	}
	catch (Exception e1) {
	e1.printStackTrace();
}
	return list; 
}
}
